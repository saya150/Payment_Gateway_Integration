const express = require('express')

const bodyParser = require("body-parser");
const Insta = require("instamojo-nodejs");



const API_KEY = "test_989774110f43ca19477c8fe2b5f";

const AUTH_KEY = "test_f771ae1068dc41973b0a88a5285";

Insta.setKeys(API_KEY, AUTH_KEY);

Insta.isSandboxMode(true);

//const PORT = process.env.PORT || 8000
const PORT = 80;
const app= express()
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


app.get('/',(req,res) => {
    res.sendFile(__dirname+"/index.html")

})
 


 app.post('/pay',(req,res) => {
  var name = req.body.name;
  var email = req.body.email;
  var amount = req.body.amount;
  console.log(name);
  console.log(email);
  console.log(amount);

});
 var data = new Insta.PaymentData();

 const REDIRECT_URL = "http://localhost:80/success";

 data.setRedirectUrl(REDIRECT_URL);
  data.send_email = "True";
 data.purpose = "Thanks for the help!!"; // REQUIRED
 data.amount = amount;
 data.name = name;
  data.email = email; // REQUIRED



  Insta.createPayment(data, function (error, response) {
    if (error) {
      // some error
    } else {
      console.log("able to pay")
      // Payment redirection link at response.payment_request.longurl
      res.send("Please check your email to make payment")
    }
 });


app.get('/success',(req,res)=> {
 res.send("Payment was successful ,check your email for the invoice")
})


app.listen(PORT, function(err){ 
  if (err) console.log("Error in server setup") 
  console.log("Server listening on Port", PORT); 

}) 

  
